def ftoc(temp)
  answer = (5.0 / 9) * (temp - 32) #Formula to convert F to C
  answer
  end

def ctof(temp)
  answer = (9.0 / 5) * temp + 32 #Formula to convert C to F
  answer
end
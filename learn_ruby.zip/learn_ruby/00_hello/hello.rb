def hello #Hello method that returns hello string with no parameters
 "Hello!"
end

def greet(who) #Greet method that returns string with single inputted parameter
 "Hello, #{who}!"
 end